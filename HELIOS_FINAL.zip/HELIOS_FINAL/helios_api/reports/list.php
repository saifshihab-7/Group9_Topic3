<?php
require_once __DIR__ . "/../config.php";

try {
  $pdo = db();

  $totalUsers = $pdo->query("SELECT COUNT(*) AS n FROM users")->fetch()["n"];
  $totalCourses = $pdo->query("SELECT COUNT(*) AS n FROM courses")->fetch()["n"];
  $totalEnrollments = $pdo->query("SELECT COUNT(*) AS n FROM course_enrollments")->fetch()["n"];
  $totalRevenue = $pdo->query("SELECT COALESCE(SUM(amount),0) AS s FROM financial_transactions WHERE type='Payment'")->fetch()["s"];

  $today = date("Y-m-d");
  $rows = [
    ["report_id"=>"RPT_USERS", "title"=>"Users Summary", "date"=>$today, "status"=>"Generated", "type"=>"System", "value"=>$totalUsers],
    ["report_id"=>"RPT_COURSES", "title"=>"Courses Summary", "date"=>$today, "status"=>"Generated", "type"=>"Academic", "value"=>$totalCourses],
    ["report_id"=>"RPT_ENROLL", "title"=>"Enrollments Summary", "date"=>$today, "status"=>"Generated", "type"=>"Academic", "value"=>$totalEnrollments],
    ["report_id"=>"RPT_REV", "title"=>"Revenue Summary", "date"=>$today, "status"=>"Generated", "type"=>"Finance", "value"=>$totalRevenue],
  ];

  json_ok($rows);
} catch (Exception $e) {
  json_err("Report generation failed", 500, ["detail"=>$e->getMessage()]);
}
?>