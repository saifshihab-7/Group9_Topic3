<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$transaction_id = array_key_exists("transaction_id", $in) ? $in["transaction_id"] : null;
if (!$transaction_id) json_err("Missing transaction_id");
try {
  $stmt = db()->prepare("DELETE FROM financial_transactions WHERE transaction_id=?");
  $stmt->execute([$transaction_id]);
  json_ok(["message"=>"Deleted"]);
} catch (Exception $e) {
  json_err("Delete failed", 500, ["detail"=>$e->getMessage()]);
}
?>