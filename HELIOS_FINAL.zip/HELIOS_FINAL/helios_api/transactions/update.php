<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$student_user_id = array_key_exists("student_user_id", $in) ? $in["student_user_id"] : null;
$amount = array_key_exists("amount", $in) ? $in["amount"] : null;
$type = array_key_exists("type", $in) ? $in["type"] : null;
$reason = array_key_exists("reason", $in) ? $in["reason"] : null;
$date = array_key_exists("date", $in) ? $in["date"] : null;
$status = array_key_exists("status", $in) ? $in["status"] : null;
$transaction_id = array_key_exists("transaction_id", $in) ? $in["transaction_id"] : null;
if (!$transaction_id) json_err("Missing transaction_id");
try {
  $stmt = db()->prepare("UPDATE financial_transactions SET student_user_id=?, amount=?, type=?, reason=?, date=?, status=? WHERE transaction_id=?");
  $stmt->execute([$student_user_id, $amount, $type, $reason, $date, $status, $transaction_id]);
  json_ok(["message"=>"Updated"]);
} catch (Exception $e) {
  json_err("Update failed", 500, ["detail"=>$e->getMessage()]);
}
?>