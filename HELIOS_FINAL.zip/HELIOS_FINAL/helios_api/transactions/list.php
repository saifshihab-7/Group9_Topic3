<?php
require_once __DIR__ . "/../config.php";
try {
  $rows = db()->query("SELECT t.transaction_id, t.student_user_id, u.name AS student_name,\n              t.amount, t.type, t.reason, t.date, t.status\n       FROM financial_transactions t\n       LEFT JOIN users u ON u.user_id=t.student_user_id\n       ORDER BY t.transaction_id")->fetchAll();
  json_ok($rows);
} catch (Exception $e) {
  json_err("List failed", 500, ["detail"=>$e->getMessage()]);
}
?>