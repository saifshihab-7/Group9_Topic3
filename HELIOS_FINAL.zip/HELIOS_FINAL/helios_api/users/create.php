<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$user_id = array_key_exists("user_id", $in) ? $in["user_id"] : null;
$role_id = array_key_exists("role_id", $in) ? $in["role_id"] : null;
$name = array_key_exists("name", $in) ? $in["name"] : null;
$email = array_key_exists("email", $in) ? $in["email"] : null;
$password_hash = array_key_exists("password_hash", $in) ? $in["password_hash"] : null;
try {
  $stmt = db()->prepare("INSERT INTO users (user_id,role_id,name,email,password_hash) VALUES (?,?,?,?,?)");
  $stmt->execute([$user_id, $role_id, $name, $email, $password_hash]);
  json_ok(["message"=>"Created"]);
} catch (Exception $e) {
  json_err("Create failed", 500, ["detail"=>$e->getMessage()]);
}
?>