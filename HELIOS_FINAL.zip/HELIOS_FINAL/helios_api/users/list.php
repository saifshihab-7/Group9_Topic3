<?php
require_once __DIR__ . "/../config.php";
try {
  $rows = db()->query("SELECT u.user_id, u.name, u.email, u.role_id, r.role_name\n       FROM users u\n       LEFT JOIN roles r ON r.role_id=u.role_id\n       ORDER BY u.user_id")->fetchAll();
  json_ok($rows);
} catch (Exception $e) {
  json_err("List failed", 500, ["detail"=>$e->getMessage()]);
}
?>