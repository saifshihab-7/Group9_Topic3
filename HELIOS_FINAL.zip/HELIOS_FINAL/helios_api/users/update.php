<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$role_id = array_key_exists("role_id", $in) ? $in["role_id"] : null;
$name = array_key_exists("name", $in) ? $in["name"] : null;
$email = array_key_exists("email", $in) ? $in["email"] : null;
$password_hash = array_key_exists("password_hash", $in) ? $in["password_hash"] : null;
$user_id = array_key_exists("user_id", $in) ? $in["user_id"] : null;
if (!$user_id) json_err("Missing user_id");
try {
  $stmt = db()->prepare("UPDATE users SET role_id=?, name=?, email=?, password_hash=? WHERE user_id=?");
  $stmt->execute([$role_id, $name, $email, $password_hash, $user_id]);
  json_ok(["message"=>"Updated"]);
} catch (Exception $e) {
  json_err("Update failed", 500, ["detail"=>$e->getMessage()]);
}
?>