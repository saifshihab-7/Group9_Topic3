<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$user_id = array_key_exists("user_id", $in) ? $in["user_id"] : null;
if (!$user_id) json_err("Missing user_id");
try {
  $stmt = db()->prepare("DELETE FROM users WHERE user_id=?");
  $stmt->execute([$user_id]);
  json_ok(["message"=>"Deleted"]);
} catch (Exception $e) {
  json_err("Delete failed", 500, ["detail"=>$e->getMessage()]);
}
?>