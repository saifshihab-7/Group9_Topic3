<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$assessment_id = array_key_exists("assessment_id", $in) ? $in["assessment_id"] : null;
$course_id = array_key_exists("course_id", $in) ? $in["course_id"] : null;
$title = array_key_exists("title", $in) ? $in["title"] : null;
$total_questions = array_key_exists("total_questions", $in) ? $in["total_questions"] : null;
$avg_score_percent = array_key_exists("avg_score_percent", $in) ? $in["avg_score_percent"] : null;
try {
  $stmt = db()->prepare("INSERT INTO assessments (assessment_id,course_id,title,total_questions,avg_score_percent) VALUES (?,?,?,?,?)");
  $stmt->execute([$assessment_id, $course_id, $title, $total_questions, $avg_score_percent]);
  json_ok(["message"=>"Created"]);
} catch (Exception $e) {
  json_err("Create failed", 500, ["detail"=>$e->getMessage()]);
}
?>