<?php
require_once __DIR__ . "/../config.php";
try {
  $rows = db()->query("SELECT a.assessment_id, a.course_id, c.title AS course_title, a.title, a.total_questions, a.avg_score_percent\n       FROM assessments a\n       LEFT JOIN courses c ON c.course_id=a.course_id\n       ORDER BY a.assessment_id")->fetchAll();
  json_ok($rows);
} catch (Exception $e) {
  json_err("List failed", 500, ["detail"=>$e->getMessage()]);
}
?>