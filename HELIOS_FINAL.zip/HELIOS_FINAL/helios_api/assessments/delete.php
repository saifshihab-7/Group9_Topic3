<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$assessment_id = array_key_exists("assessment_id", $in) ? $in["assessment_id"] : null;
if (!$assessment_id) json_err("Missing assessment_id");
try {
  $stmt = db()->prepare("DELETE FROM assessments WHERE assessment_id=?");
  $stmt->execute([$assessment_id]);
  json_ok(["message"=>"Deleted"]);
} catch (Exception $e) {
  json_err("Delete failed", 500, ["detail"=>$e->getMessage()]);
}
?>