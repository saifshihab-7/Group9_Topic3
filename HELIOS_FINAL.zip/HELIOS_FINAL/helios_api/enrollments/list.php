<?php
require_once __DIR__ . "/../config.php";
try {
  $rows = db()->query("SELECT e.enrollment_id, e.student_user_id, su.name AS student_name,\n              e.course_id, c.title AS course_title,\n              e.enrollment_date, e.progress_percent, e.time_spent_hrs, e.payment_status\n       FROM course_enrollments e\n       LEFT JOIN users su ON su.user_id=e.student_user_id\n       LEFT JOIN courses c ON c.course_id=e.course_id\n       ORDER BY e.enrollment_id")->fetchAll();
  json_ok($rows);
} catch (Exception $e) {
  json_err("List failed", 500, ["detail"=>$e->getMessage()]);
}
?>