<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$enrollment_id = array_key_exists("enrollment_id", $in) ? $in["enrollment_id"] : null;
$student_user_id = array_key_exists("student_user_id", $in) ? $in["student_user_id"] : null;
$course_id = array_key_exists("course_id", $in) ? $in["course_id"] : null;
$enrollment_date = array_key_exists("enrollment_date", $in) ? $in["enrollment_date"] : null;
$progress_percent = array_key_exists("progress_percent", $in) ? $in["progress_percent"] : null;
$time_spent_hrs = array_key_exists("time_spent_hrs", $in) ? $in["time_spent_hrs"] : null;
$payment_status = array_key_exists("payment_status", $in) ? $in["payment_status"] : null;
try {
  $stmt = db()->prepare("INSERT INTO course_enrollments (enrollment_id,student_user_id,course_id,enrollment_date,progress_percent,time_spent_hrs,payment_status) VALUES (?,?,?,?,?,?,?)");
  $stmt->execute([$enrollment_id, $student_user_id, $course_id, $enrollment_date, $progress_percent, $time_spent_hrs, $payment_status]);
  json_ok(["message"=>"Created"]);
} catch (Exception $e) {
  json_err("Create failed", 500, ["detail"=>$e->getMessage()]);
}
?>