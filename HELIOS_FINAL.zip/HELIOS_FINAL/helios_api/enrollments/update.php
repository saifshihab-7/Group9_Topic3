<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$student_user_id = array_key_exists("student_user_id", $in) ? $in["student_user_id"] : null;
$course_id = array_key_exists("course_id", $in) ? $in["course_id"] : null;
$enrollment_date = array_key_exists("enrollment_date", $in) ? $in["enrollment_date"] : null;
$progress_percent = array_key_exists("progress_percent", $in) ? $in["progress_percent"] : null;
$time_spent_hrs = array_key_exists("time_spent_hrs", $in) ? $in["time_spent_hrs"] : null;
$payment_status = array_key_exists("payment_status", $in) ? $in["payment_status"] : null;
$enrollment_id = array_key_exists("enrollment_id", $in) ? $in["enrollment_id"] : null;
if (!$enrollment_id) json_err("Missing enrollment_id");
try {
  $stmt = db()->prepare("UPDATE course_enrollments SET student_user_id=?, course_id=?, enrollment_date=?, progress_percent=?, time_spent_hrs=?, payment_status=? WHERE enrollment_id=?");
  $stmt->execute([$student_user_id, $course_id, $enrollment_date, $progress_percent, $time_spent_hrs, $payment_status, $enrollment_id]);
  json_ok(["message"=>"Updated"]);
} catch (Exception $e) {
  json_err("Update failed", 500, ["detail"=>$e->getMessage()]);
}
?>