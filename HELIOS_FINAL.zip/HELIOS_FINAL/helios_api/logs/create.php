<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$log_id = array_key_exists("log_id", $in) ? $in["log_id"] : null;
$user_id = array_key_exists("user_id", $in) ? $in["user_id"] : null;
$activity = array_key_exists("activity", $in) ? $in["activity"] : null;
$ip_address = array_key_exists("ip_address", $in) ? $in["ip_address"] : null;
$status = array_key_exists("status", $in) ? $in["status"] : null;
try {
  $stmt = db()->prepare("INSERT INTO system_logs (log_id,user_id,activity,ip_address,status) VALUES (?,?,?,?,?)");
  $stmt->execute([$log_id, $user_id, $activity, $ip_address, $status]);
  json_ok(["message"=>"Created"]);
} catch (Exception $e) {
  json_err("Create failed", 500, ["detail"=>$e->getMessage()]);
}
?>