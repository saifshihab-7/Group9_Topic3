<?php
require_once __DIR__ . "/../config.php";
try {
  $rows = db()->query("SELECT l.log_id, l.user_id, u.name AS user_name, l.activity, l.timestamp, l.ip_address, l.status\n       FROM system_logs l\n       LEFT JOIN users u ON u.user_id=l.user_id\n       ORDER BY l.timestamp DESC")->fetchAll();
  json_ok($rows);
} catch (Exception $e) {
  json_err("List failed", 500, ["detail"=>$e->getMessage()]);
}
?>