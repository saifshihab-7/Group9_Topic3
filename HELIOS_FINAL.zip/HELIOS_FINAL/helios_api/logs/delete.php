<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$log_id = array_key_exists("log_id", $in) ? $in["log_id"] : null;
if (!$log_id) json_err("Missing log_id");
try {
  $stmt = db()->prepare("DELETE FROM system_logs WHERE log_id=?");
  $stmt->execute([$log_id]);
  json_ok(["message"=>"Deleted"]);
} catch (Exception $e) {
  json_err("Delete failed", 500, ["detail"=>$e->getMessage()]);
}
?>