<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$user_id = array_key_exists("user_id", $in) ? $in["user_id"] : null;
$activity = array_key_exists("activity", $in) ? $in["activity"] : null;
$ip_address = array_key_exists("ip_address", $in) ? $in["ip_address"] : null;
$status = array_key_exists("status", $in) ? $in["status"] : null;
$log_id = array_key_exists("log_id", $in) ? $in["log_id"] : null;
if (!$log_id) json_err("Missing log_id");
try {
  $stmt = db()->prepare("UPDATE system_logs SET user_id=?, activity=?, ip_address=?, status=? WHERE log_id=?");
  $stmt->execute([$user_id, $activity, $ip_address, $status, $log_id]);
  json_ok(["message"=>"Updated"]);
} catch (Exception $e) {
  json_err("Update failed", 500, ["detail"=>$e->getMessage()]);
}
?>