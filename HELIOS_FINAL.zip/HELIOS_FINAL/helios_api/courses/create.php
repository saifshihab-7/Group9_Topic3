<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$course_id = array_key_exists("course_id", $in) ? $in["course_id"] : null;
$title = array_key_exists("title", $in) ? $in["title"] : null;
$instructor_user_id = array_key_exists("instructor_user_id", $in) ? $in["instructor_user_id"] : null;
$enrolled_count = array_key_exists("enrolled_count", $in) ? $in["enrolled_count"] : null;
$capacity = array_key_exists("capacity", $in) ? $in["capacity"] : null;
$rating = array_key_exists("rating", $in) ? $in["rating"] : null;
$status = array_key_exists("status", $in) ? $in["status"] : null;
try {
  $stmt = db()->prepare("INSERT INTO courses (course_id,title,instructor_user_id,enrolled_count,capacity,rating,status) VALUES (?,?,?,?,?,?,?)");
  $stmt->execute([$course_id, $title, $instructor_user_id, $enrolled_count, $capacity, $rating, $status]);
  json_ok(["message"=>"Created"]);
} catch (Exception $e) {
  json_err("Create failed", 500, ["detail"=>$e->getMessage()]);
}
?>