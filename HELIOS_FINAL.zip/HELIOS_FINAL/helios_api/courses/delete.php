<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$course_id = array_key_exists("course_id", $in) ? $in["course_id"] : null;
if (!$course_id) json_err("Missing course_id");
try {
  $stmt = db()->prepare("DELETE FROM courses WHERE course_id=?");
  $stmt->execute([$course_id]);
  json_ok(["message"=>"Deleted"]);
} catch (Exception $e) {
  json_err("Delete failed", 500, ["detail"=>$e->getMessage()]);
}
?>