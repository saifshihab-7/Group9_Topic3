<?php
require_once __DIR__ . "/../config.php";
try {
  $rows = db()->query("SELECT c.course_id, c.title, c.instructor_user_id,\n              u.name AS instructor_name,\n              c.enrolled_count, c.capacity, c.rating, c.status\n       FROM courses c\n       LEFT JOIN users u ON u.user_id = c.instructor_user_id\n       ORDER BY c.course_id")->fetchAll();
  json_ok($rows);
} catch (Exception $e) {
  json_err("List failed", 500, ["detail"=>$e->getMessage()]);
}
?>