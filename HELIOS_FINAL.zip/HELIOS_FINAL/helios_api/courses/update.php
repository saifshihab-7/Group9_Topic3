<?php
require_once __DIR__ . "/../config.php";
$in = input_json();
$title = array_key_exists("title", $in) ? $in["title"] : null;
$instructor_user_id = array_key_exists("instructor_user_id", $in) ? $in["instructor_user_id"] : null;
$enrolled_count = array_key_exists("enrolled_count", $in) ? $in["enrolled_count"] : null;
$capacity = array_key_exists("capacity", $in) ? $in["capacity"] : null;
$rating = array_key_exists("rating", $in) ? $in["rating"] : null;
$status = array_key_exists("status", $in) ? $in["status"] : null;
$course_id = array_key_exists("course_id", $in) ? $in["course_id"] : null;
if (!$course_id) json_err("Missing course_id");
try {
  $stmt = db()->prepare("UPDATE courses SET title=?, instructor_user_id=?, enrolled_count=?, capacity=?, rating=?, status=? WHERE course_id=?");
  $stmt->execute([$title, $instructor_user_id, $enrolled_count, $capacity, $rating, $status, $course_id]);
  json_ok(["message"=>"Updated"]);
} catch (Exception $e) {
  json_err("Update failed", 500, ["detail"=>$e->getMessage()]);
}
?>